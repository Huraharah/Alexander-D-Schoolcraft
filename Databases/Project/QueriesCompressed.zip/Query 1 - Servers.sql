SELECT Type as HwType, Model as model
FROM hardware
WHERE Type = 'server';