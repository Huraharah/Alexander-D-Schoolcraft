SELECT COUNT(SerialNo) as AssetCount, SUM(Price) as AssetsTotalPrice
FROM hardware;